<?php
	include(dirname(__FILE__) . '/active-directory-integration/ad-integration.php');
?>
