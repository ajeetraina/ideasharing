Active Directory Integration for WordPress MU

------------------------------------------------------------------------------
Version:  0.9.7
Date:     2009-08-17
Author:   Christoph Steindorff <christoph.steindorff[at]ecw.de>
Homepage: http://blog.ecw.de/
------------------------------------------------------------------------------

This is the first release of ADI with some WordPress MU support. It�s 
recommended not use it in production environments.

If automatic account creation is switched on, then the new users will be
assigned to the first (#1) blog. The admin needs to assign the users to the
specific blogs manually. 

Active Directory Integration for WordPress MU has to be installed manually.
1. Copy "ad-integration_loader.php" to "wp-content/mu-plugins"
2. The Plugin itself has to reside in 
   "wp-content/mu-plugins/active-directory-integration"

